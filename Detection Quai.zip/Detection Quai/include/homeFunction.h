#ifndef HOMEFUNCTION_H_INCLUDED
#define HOMEFUNCTION_H_INCLUDED

void cube(double longueur, double largeur, double hauteur);

#endif // HOMEFUNCTION_H_INCLUDED
