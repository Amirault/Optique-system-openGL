#ifndef INIT_H_INCLUDED
#define INIT_H_INCLUDED

void initSDL(void);
void initOpenGL(void);

#endif // INIT_H_INCLUDED
