#include "Porte.h"

Porte::Porte()
{
    //ctor
}

Porte::~Porte()
{
    //dtor
}

Porte::Porte(const Porte& other)
{
    //copy ctor
}

void Porte::Ouvrir()
{

}

void Porte::Fermet()
{

}
